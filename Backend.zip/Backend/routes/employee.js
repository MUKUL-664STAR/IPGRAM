const express = require('express');
const router = express.Router();
const employeeController = require('../controllers/employeeController');
const authMiddleware = require('../middleware/authMiddleware');

router.use(authMiddleware.authenticate);

router.post('/create', authMiddleware.isManager, employeeController.create);
router.get('/list', employeeController.list);
router.get('/details/:id', employeeController.details);
router.put('/update/:id', authMiddleware.isManager, employeeController.update);
router.delete('/delete/:id', authMiddleware.isManager, employeeController.delete);

module.exports = router;
