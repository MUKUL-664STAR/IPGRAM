const express = require('express');
const router = express.Router();
const departmentController = require('../controllers/departmentController');
const authMiddleware = require('../middleware/authMiddleware');

router.use(authMiddleware.authenticate); // Middleware to ensure authentication for subsequent routes

router.post('/create', authMiddleware.isManager, departmentController.create);
router.get('/list', departmentController.list);
router.put('/update/:id', authMiddleware.isManager, departmentController.update);
router.delete('/delete/:id', authMiddleware.isManager, departmentController.delete);

module.exports = router;
